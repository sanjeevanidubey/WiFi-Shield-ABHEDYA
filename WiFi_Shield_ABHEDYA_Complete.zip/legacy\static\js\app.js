/**
 * WiFi Shield ABHEDYA - Core Logic
 * High-security, Cyber-Tactical Interface
 */

class SoundEngine {
    constructor() {
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    }

    async play(type) {
        if (this.ctx.state === 'suspended') {
            await this.ctx.resume();
        }

        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        
        osc.connect(gain);
        gain.connect(this.ctx.destination);

        const now = this.ctx.currentTime;

        switch (type) {
            case 'boot': // Low power-up hum
                osc.type = 'sine';
                osc.frequency.setValueAtTime(50, now);
                osc.frequency.exponentialRampToValueAtTime(200, now + 1.5);
                gain.gain.setValueAtTime(0, now);
                gain.gain.linearRampToValueAtTime(0.3, now + 0.1);
                gain.gain.linearRampToValueAtTime(0, now + 1.5);
                osc.start(now);
                osc.stop(now + 1.5);
                break;

            case 'chirp': // UI click/hover
                osc.type = 'square';
                osc.frequency.setValueAtTime(800, now);
                osc.frequency.exponentialRampToValueAtTime(1200, now + 0.05);
                gain.gain.setValueAtTime(0.1, now);
                gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
                osc.start(now);
                osc.stop(now + 0.05);
                break;

            case 'sonar': // Radar ping
                osc.type = 'sine';
                osc.frequency.setValueAtTime(1000, now);
                gain.gain.setValueAtTime(0.2, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 1);
                osc.start(now);
                osc.stop(now + 1);
                break;

            case 'warning': // Alert pulse
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(440, now);
                osc.frequency.setValueAtTime(330, now + 0.2);
                gain.gain.setValueAtTime(0.1, now);
                gain.gain.linearRampToValueAtTime(0.1, now + 0.4);
                gain.gain.linearRampToValueAtTime(0, now + 0.5);
                osc.start(now);
                osc.stop(now + 0.5);
                break;

            case 'success': // Clean beep
                osc.type = 'sine';
                osc.frequency.setValueAtTime(880, now);
                osc.frequency.setValueAtTime(1760, now + 0.1);
                gain.gain.setValueAtTime(0.1, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
                osc.start(now);
                osc.stop(now + 0.3);
                break;
        }
    }
}

const sounds = new SoundEngine();

// --- Security Module ---
const Security = {
    sanitize(input) {
        // Remove script tags and potentially harmful characters
        return input.replace(/<[^>]*>?/gm, '').trim();
    },
    
    validateCredentials(user, key) {
        // In a real app, this would be a server-side hash check.
        // For this HUD experience, we enforce a basic length/presence check.
        const cleanUser = this.sanitize(user);
        const cleanKey = this.sanitize(key);
        
        if (cleanUser.length > 3 && cleanKey.length > 5) {
            return true;
        }
        return false;
    }
};

// --- App Controller ---
const App = {
    state: 'LOGIN', // LOGIN -> SCANNING -> RESULTS
    startTime: Date.now(),

    init() {
        this.bindEvents();
        this.updateUptime();
        sounds.play('boot');
    },

    bindEvents() {
        const loginBtn = document.getElementById('login-btn');
        const inputs = document.querySelectorAll('input');

        loginBtn.addEventListener('click', () => this.handleLogin());
        
        inputs.forEach(input => {
            input.addEventListener('mouseenter', () => sounds.play('chirp'));
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.handleLogin();
            });
        });
    },

    handleLogin() {
        const user = document.getElementById('username').value;
        const key = document.getElementById('access-key').value;
        const errorMsg = document.getElementById('login-error');

        if (Security.validateCredentials(user, key)) {
            errorMsg.style.display = 'none';
            this.transitionTo('SCANNING');
        } else {
            errorMsg.style.display = 'block';
            sounds.play('warning');
            // Shake effect
            const box = document.getElementById('login-section');
            box.style.animation = 'none';
            box.offsetHeight; // trigger reflow
            box.style.animation = 'shake 0.5s';
        }
    },

    transitionTo(newState) {
        // Route Guard: Prevent skipping
        if (this.state === 'LOGIN' && newState === 'RESULTS') return;

        const loginSec = document.getElementById('login-section');
        const scanSec = document.getElementById('scan-section');
        const resSec = document.getElementById('result-section');

        // Hide all
        loginSec.style.display = 'none';
        scanSec.style.display = 'none';
        resSec.style.display = 'none';

        this.state = newState;

        if (newState === 'SCANNING') {
            scanSec.style.display = 'flex';
            this.runScanningPhase();
        } else if (newState === 'RESULTS') {
            resSec.style.display = 'flex';
            sounds.play('success');
        }
    },

    runScanningPhase() {
        const status = document.getElementById('scan-status');
        const nodesContainer = document.getElementById('radar-nodes');
        const listContainer = document.getElementById('network-list');
        let progress = 0;

        const messages = [
            "ANALYZING FREQUENCY SPECTRUM...",
            "DECRYPTING HANDSHAKES...",
            "CHECKING SSL CERTIFICATES...",
            "VERIFYING SSID INTEGRITY...",
            "MAPPING TOPOLOGY..."
        ];

        // Start fetching data in background
        const dataPromise = fetch('/api/scan')
            .then(res => res.json())
            .catch(err => ({ error: true, msg: err }));

        const scanInterval = setInterval(async () => {
            sounds.play('sonar');
            
            // Randomly inject radar nodes
            const node = document.createElement('div');
            node.className = 'node';
            const angle = Math.random() * Math.PI * 2;
            const dist = 50 + Math.random() * 80;
            node.style.left = `calc(50% + ${Math.cos(angle) * dist}px)`;
            node.style.top = `calc(50% + ${Math.sin(angle) * dist}px)`;
            nodesContainer.appendChild(node);

            status.innerText = messages[Math.floor(Math.random() * messages.length)];
            
            progress += 20;
            if (progress >= 100) {
                clearInterval(scanInterval);
                
                const data = await dataPromise;
                if (data.error) {
                    status.innerText = "CRITICAL ERROR: SCAN INTERRUPTED";
                    status.style.color = 'var(--alert-red)';
                    sounds.play('warning');
                    return;
                }

                this.renderResults(data.networks);
                setTimeout(() => this.transitionTo('RESULTS'), 800);
            }
        }, 1200);
    },

    renderResults(networks) {
        const listContainer = document.getElementById('network-list');
        listContainer.innerHTML = ''; // Clear hardcoded

        networks.forEach(net => {
            const card = document.createElement('div');
            card.className = `network-card ${net.status}`;
            card.innerHTML = `
                <div>
                    <div style="font-weight: bold; margin-bottom: 5px;">SSID: ${net.ssid}</div>
                    <div style="font-size: 0.7rem;">STATUS: ${net.description}</div>
                </div>
                <div>
                    <div style="font-size: 0.7rem; margin-bottom: 5px;">Trust Score: ${net.status.toUpperCase()} (${net.trust_score}%)</div>
                    <div class="progress-container"><div class="progress-bar" style="width: ${net.trust_score}%"></div></div>
                </div>
            `;
            listContainer.appendChild(card);
        });
    },

    updateUptime() {
        setInterval(() => {
            const diff = Math.floor((Date.now() - this.startTime) / 1000);
            const hrs = String(Math.floor(diff / 3600)).padStart(2, '0');
            const mins = String(Math.floor((diff % 3600) / 60)).padStart(2, '0');
            const secs = String(diff % 60).padStart(2, '0');
            document.getElementById('uptime').innerText = `${hrs}:${mins}:${secs}`;
        }, 1000);
    }
};

// Add shake animation to CSS programmatically
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }
`;
document.head.appendChild(style);

// Initialize app on load
window.onload = () => App.init();
