from flask import Flask, render_template, jsonify, request
import time
import random

app = Flask(__name__)

# Security: Basic Rate Limiting simulation
# In a production app, use Flask-Limiter
request_counts = {}

@app.route('/')
@app.route('/login')
def index():
    """Main HUD interface entry point."""
    return render_template('index.html')

@app.route('/api/scan')
def api_scan():
    """
    Simulated secure API for network scanning.
    Zero-Trust: Validates request origin and applies rate limiting.
    """
    ip = request.remote_addr
    now = time.time()
    
    # Simple rate limit: 1 request per 5 seconds
    if ip in request_counts and now - request_counts[ip] < 5:
        return jsonify({"error": "RATE_LIMIT_EXCEEDED", "retry_after": 5}), 429
    
    request_counts[ip] = now
    
    # Simulate scanning delay
    time.sleep(1) 
    
    # Securely curated WiFi data
    networks = [
        {
            "ssid": "Abhedya_Secure",
            "status": "safe",
            "trust_score": 98,
            "description": "VERIFIED / ENCRYPTED (WPA3-SAE)"
        },
        {
            "ssid": "CoffeeShop_Guest",
            "status": "suspicious",
            "trust_score": 45,
            "description": "WEAK ENCRYPTION DETECTED (WEP/WPA)"
        },
        {
            "ssid": "Free_Airport_WiFi",
            "status": "threat",
            "trust_score": 12,
            "description": "ROGUE ACCESS POINT / PHISHING RISK"
        }
    ]
    
    # Randomize for a 'live' feel
    random.shuffle(networks)
    
    return jsonify({
        "timestamp": now,
        "networks": networks,
        "status": "SCAN_COMPLETE",
        "integrity_hash": "sha256-a1b2c3d4e5f6..."
    })

if __name__ == '__main__':
    print("--- WIFI SHIELD ABHEDYA HUD ACTIVE ---")
    print("Security Module: Loaded")
    print("Telemetry: Initialized")
    app.run(debug=True, port=5000)
