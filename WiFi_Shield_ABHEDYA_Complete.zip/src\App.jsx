import React, { useState, useEffect, useCallback } from 'react';
import { sounds } from './utils/sounds';
import { Shield, Lock, Cpu, Radar as RadarIcon, AlertTriangle, CheckCircle, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import CryptoJS from 'crypto-js';

// --- Components ---

const Telemetry = () => (
  <div className="fixed inset-0 pointer-events-none z-50 p-6 font-mono text-[10px] text-cyber-cyan/60 uppercase tracking-widest">
    <div className="absolute top-6 left-6">
      SYS_ON: <span className="text-cyber-green">ACTIVE</span><br />
      SEC_LEVEL: ALPHA-9<br />
      ENCRYPT: AES-256
    </div>
    <div className="absolute top-6 right-6 text-right">
      REC_4K: <span className="text-cyber-red animate-pulse">● LIVE</span><br />
      BUFFER: 1024KB/S<br />
      ID: ABHEDYA_01
    </div>
    <div className="absolute bottom-20 left-6">
      LAT: 28.6139° N<br />
      LON: 77.2090° E<br />
      ALT: 216M
    </div>
  </div>
);

const BackgroundGrid = () => (
  <div className="fixed inset-0 bg-cyber-bg z-[-1]">
    <div className="absolute inset-0 bg-grid-nodes opacity-20"></div>
    <div className="absolute inset-0 bg-gradient-to-t from-cyber-bg via-transparent to-transparent"></div>
    <div className="scanline"></div>
  </div>
);

const Login = ({ onConnect }) => {
  const [operator, setOperator] = useState('');
  const [key, setKey] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    // Strict RegEx: Alphanumeric only
    const regex = /^[a-zA-Z0-9]+$/;
    if (!regex.test(operator) || !regex.test(key)) {
      setError('ACCESS DENIED: ILLEGAL CHARACTERS DETECTED');
      sounds.play('threat');
      return;
    }

    // Client-side hashing
    const hashedKey = CryptoJS.SHA256(key).toString();
    console.log('Auth Hash:', hashedKey); // Simulated submission

    sounds.play('success');
    onConnect();
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="glass-panel p-10 w-full max-w-md relative overflow-hidden"
    >
      <div className="absolute top-0 left-0 w-full h-1 bg-cyber-cyan animate-pulse"></div>
      <div className="flex flex-col items-center mb-8">
        <Shield className="w-16 h-16 text-cyber-cyan mb-4 animate-pulse" />
        <h1 className="text-2xl font-bold tracking-[0.5em] text-center">WIFI SHIELD<br/>ABHEDYA</h1>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-[10px] text-cyber-cyan/50 mb-1">OPERATOR_ID</label>
          <input 
            type="text" 
            value={operator}
            onChange={(e) => { setOperator(e.target.value); sounds.play('clack'); }}
            className="terminal-input w-full"
            placeholder="ENTER_ID"
          />
        </div>
        <div>
          <label className="block text-[10px] text-cyber-cyan/50 mb-1">ENCRYPTED_KEY</label>
          <input 
            type="password" 
            value={key}
            onChange={(e) => { setKey(e.target.value); sounds.play('clack'); }}
            className="terminal-input w-full"
            placeholder="********"
          />
        </div>
        {error && <div className="text-cyber-red text-[10px] animate-bounce">{error}</div>}
        <button 
          onClick={handleLogin}
          className="cyber-btn w-full mt-4"
        >
          ESTABLISH SECURE LINK
        </button>
      </div>
    </motion.div>
  );
};

const Radar = ({ onComplete }) => {
  useEffect(() => {
    sounds.play('startup');
    const interval = setInterval(() => sounds.play('whoosh'), 1500);
    const timeout = setTimeout(() => {
      clearInterval(interval);
      onComplete();
    }, 3000);
    return () => { clearTimeout(timeout); clearInterval(interval); };
  }, [onComplete]);

  return (
    <div className="flex flex-col items-center">
      <h2 className="text-xl tracking-[0.3em] mb-12 animate-pulse">INITIATING DEEP SCAN</h2>
      <div className="relative w-80 h-80 border-2 border-cyber-cyan/30 rounded-full flex items-center justify-center">
        <div className="absolute inset-0 border-2 border-cyber-cyan/10 rounded-full scale-75"></div>
        <div className="absolute inset-0 border-2 border-cyber-cyan/5 rounded-full scale-50"></div>
        
        {/* Sweep */}
        <div className="absolute inset-0 rounded-full animate-radar-sweep bg-[conic-gradient(from_0deg,transparent_80%,rgba(0,255,255,0.4))]"></div>
        
        {/* Nodes */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="absolute top-1/4 left-1/3 w-2 h-2 bg-cyber-cyan rounded-full shadow-[0_0_10px_#00FFFF]"
        />
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute top-1/3 right-1/4 w-2 h-2 bg-cyber-cyan rounded-full shadow-[0_0_10px_#00FFFF]"
        />
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-1/3 right-1/4 w-2 h-2 bg-cyber-red rounded-full shadow-[0_0_10px_#FF0000]"
        />
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.8 }}
          className="absolute bottom-1/4 left-1/4 w-2 h-2 bg-cyber-cyan rounded-full shadow-[0_0_10px_#00FFFF]"
        />
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.1 }}
          className="absolute top-1/2 right-1/2 w-2 h-2 bg-cyber-yellow rounded-full shadow-[0_0_10px_#FFFF00]"
        />
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.4 }}
          className="absolute top-2/3 left-1/2 w-2 h-2 bg-cyber-cyan rounded-full shadow-[0_0_10px_#00FFFF]"
        />
        
        <Activity className="w-12 h-12 text-cyber-cyan/50 animate-pulse" />
      </div>
      <div className="mt-8 text-[10px] text-cyber-cyan/60 font-mono">
        SCANNING_FREQUENCY: 2.4GHz / 5.8GHz<br/>
        PACKETS_CAPTURED: 4096
      </div>
    </div>
  );
};

const Dashboard = () => {
  const networks = [
    { ssid: "JSS GH", status: "SAFE", color: "text-cyber-green", icon: CheckCircle, score: 98 },
    { ssid: "JSS 126", status: "SAFE", color: "text-cyber-green", icon: CheckCircle, score: 96 },
    { ssid: "JSS GUEST ROOM", status: "SUSPICIOUS", color: "text-cyber-yellow", icon: AlertTriangle, score: 45 },
    { ssid: "Butterfly", status: "SAFE", color: "text-cyber-green", icon: CheckCircle, score: 92 },
    { ssid: "Sunaina M16", status: "SAFE", color: "text-cyber-green", icon: CheckCircle, score: 99 },
    { ssid: "JSS 110", status: "FAKE / ROGUE AP", color: "text-cyber-red", icon: Shield, score: 12 },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-4xl"
    >
      <h2 className="text-2xl font-bold mb-8 text-center tracking-widest border-b border-cyber-cyan/30 pb-4">
        THREAT ANALYSIS REPORT
      </h2>
      
      <div className="space-y-4">
        {networks.map((net, i) => (
          <motion.div 
            key={net.ssid}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: i * 0.2 }}
            className="glass-panel p-6 flex items-center justify-between group hover:bg-cyber-cyan/5 transition-all"
          >
            <div className="flex items-center gap-6">
              <net.icon className={`w-8 h-8 ${net.color}`} />
              <div>
                <div className="text-xs text-cyber-cyan/50">SSID</div>
                <div className="text-lg font-bold">{net.ssid}</div>
              </div>
            </div>
            
            <div className="flex gap-12 items-center">
              <div className="text-right">
                <div className="text-xs text-cyber-cyan/50">INTEGRITY_STATUS</div>
                <div className={`text-sm font-bold ${net.color}`}>{net.status}</div>
              </div>
              <div className="w-32">
                <div className="text-xs text-cyber-cyan/50 mb-1">TRUST_SCORE</div>
                <div className="h-1.5 w-full bg-cyber-grid rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${net.score}%` }}
                    className={`h-full ${net.status === 'SAFE' ? 'bg-cyber-green' : net.status === 'SUSPICIOUS' ? 'bg-cyber-yellow' : 'bg-cyber-red'}`}
                  />
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-12 flex justify-center">
        <button onClick={() => window.location.reload()} className="cyber-btn flex items-center gap-2">
          <Activity className="w-4 h-4" /> RE-INITIALIZE SCAN
        </button>
      </div>
    </motion.div>
  );
};

// --- Main App ---

export default function App() {
  const [step, setStep] = useState('LOGIN'); // LOGIN -> SCANNING -> DASHBOARD

  useEffect(() => {
    // Immersion: Disable Right-Click
    const handleContext = (e) => e.preventDefault();
    document.addEventListener('contextmenu', handleContext);
    return () => document.removeEventListener('contextmenu', handleContext);
  }, []);

  const handleStartScan = () => {
    sounds.init();
    setStep('SCANNING');
  };

  return (
    <main className="min-h-screen w-full flex items-center justify-center p-6 font-mono text-cyber-cyan selection:bg-cyber-cyan selection:text-black">
      <BackgroundGrid />
      <Telemetry />

      <AnimatePresence mode="wait">
        {step === 'LOGIN' && (
          <Login key="login" onConnect={handleStartScan} />
        )}
        {step === 'SCANNING' && (
          <Radar key="radar" onComplete={() => setStep('DASHBOARD')} />
        )}
        {step === 'DASHBOARD' && (
          <Dashboard key="dashboard" />
        )}
      </AnimatePresence>

      <footer className="fixed bottom-0 w-full p-6 flex flex-col items-center pointer-events-none opacity-50">
        <div className="text-[10px] tracking-[0.5em] mb-2 uppercase">DETECT FAKE WIFI NETWORKS. STAY ABHEDYA.</div>
        <div className="fixed bottom-6 right-6 text-[8px] text-right">
          BUILT BY SANJEEVANI, KASHISH, AND SUNAINA<br/>
          &copy; 2026 ABHEDYA_SHIELD
        </div>
      </footer>
    </main>
  );
}
