# WiFi Shield ABHEDYA - Source Code

This folder contains the complete source code for the "WiFi Shield ABHEDYA" Cyber-Tactical HUD application.

## Project Structure
- `src/`: Core React components, design system, and Sound Engine.
- `public/`: Static assets.
- `legacy/`: The original Flask/HTML prototype (for reference).
- `index.html`: Entry point.
- `package.json`: Project dependencies and scripts.
- `tailwind.config.cjs`: Theme configuration and Cyber-Tactical color palette.

## Installation & Setup
To run this project locally:

1. **Install Node.js** (if not already installed).
2. Open a terminal in this directory.
3. Run `npm install` to install all dependencies.
4. Run `npm run dev` to start the development server.
5. Open `http://localhost:5173` in your browser.

## Security Features
- **Input Sanitization**: Alphanumeric RegEx validation.
- **State Protection**: Dashboard is inaccessible until the scan completes.
- **Client-Side Hashing**: Secure credential handling.
- **Immersion Mode**: Disabled right-click/inspect.

## Credits
**Developed by Sanjeevani, Kashish, and Sunaina.**

"DETECT FAKE WIFI NETWORKS. STAY ABHEDYA."
